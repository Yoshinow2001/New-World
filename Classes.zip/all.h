#pragma once

#include"src/head.h"
#include"src/scene.h"
#include"src/config.h"
#include"src/ui.h"
#include"src/scene.hpp"
#include"src/config.hpp"
#include"src/ui.hpp"
#include"src/scene.cpp"
#include"src/config.cpp"
#include"src/ui.cpp"

