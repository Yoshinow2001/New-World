#pragma once

#include<stdint.h>

using s0=int8_t;
using s1=int16_t;
using s2=int32_t;
using s3=int64_t;

using u0=uint8_t;
using u1=uint16_t;
using u2=uint32_t;
using u3=uint64_t;

using f2=float;
using f3=double;
