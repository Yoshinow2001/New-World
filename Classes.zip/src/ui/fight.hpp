#pragma once


struct Fight: cocos2d::Scene
{
	CREATE_FUNC(Fight)
	void start(std::string key,s2 level);
};
