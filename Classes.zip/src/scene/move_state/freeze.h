#pragma once

struct Freeze;
