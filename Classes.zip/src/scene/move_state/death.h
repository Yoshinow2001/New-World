#pragma once

struct Death;
