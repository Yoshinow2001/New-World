#pragma once

Damage::Damage(f3 x):x(x){}
