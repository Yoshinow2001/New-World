#pragma once

struct Event_Cache;
