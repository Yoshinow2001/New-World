#pragma once

struct AI_MS;
