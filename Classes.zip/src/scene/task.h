#pragma once

struct Task;
