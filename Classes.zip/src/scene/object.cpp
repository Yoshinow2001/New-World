#pragma once

Object::Object(Scene*scene,s2 阵营,Pos pos):
	scene(scene),阵营(阵营),pos(pos)
{}
