#pragma once

struct Damage;
