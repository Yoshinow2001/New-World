#pragma once

struct Conditional_Task;
