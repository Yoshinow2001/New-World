#pragma once

enum class Event_T:u2;
struct Event;
