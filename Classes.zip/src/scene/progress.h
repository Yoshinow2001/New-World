#pragma once

struct Progress;
