#pragma once

void Task::operator()()
{
	task();
}
