#pragma once

struct Armature;
struct Armature_Son;
