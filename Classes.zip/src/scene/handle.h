#pragma once

struct Handle;
