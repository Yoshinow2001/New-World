#pragma once

using Pos=Vector;
