#pragma once

namespace Config
{
	#include "config/attribute.h"
	#include "config/attributes.h"
	#include "config/move_state.h"
	#include "config/skill.h"
	#include "config/weapon.h"
	#include "config/people.h"
	#include "config/scene.h"
};

