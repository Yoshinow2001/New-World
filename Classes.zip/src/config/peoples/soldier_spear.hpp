#pragma once

void soldier_spear_init();

