#pragma once

void robotboss_init();

