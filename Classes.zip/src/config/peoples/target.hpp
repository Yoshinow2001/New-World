#pragma once

void target_init();

