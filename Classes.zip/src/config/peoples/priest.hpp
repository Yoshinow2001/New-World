#pragma once

void priest_init();

