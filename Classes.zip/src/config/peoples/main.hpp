#pragma once

void main_init();

