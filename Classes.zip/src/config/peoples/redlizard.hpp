#pragma once

void redlizard_init();

