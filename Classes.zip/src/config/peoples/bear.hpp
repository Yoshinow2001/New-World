#pragma once

void bear_init();

