#pragma once

void soldier_sword_init();

