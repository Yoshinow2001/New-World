#pragma once

struct Scene;
