#pragma once

struct People;