#pragma once

struct Chapter11:Progress
{
	int j=0,cnt=0;
	Chapter11(::Scene::Scene*scene);
};

void chapter11_init();