#pragma once

struct Chapter21:Progress
{
	int j=0,cnt=0;
	Chapter21(::Scene::Scene*scene);
};

void chapter21_init();