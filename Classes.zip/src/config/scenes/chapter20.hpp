#pragma once

struct Chapter20:Progress
{
	int j=0;
	Chapter20(::Scene::Scene*scene);
};

void chapter20_init();