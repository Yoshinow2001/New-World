#pragma once

struct Weapon;
